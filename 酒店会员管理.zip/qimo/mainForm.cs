﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace qimo
{
    public partial class mainForm : Form
    {
        
        public mainForm()
        {
            InitializeComponent();

        }




        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void manager_Load(object sender, EventArgs e)
        {
            this.MaximizeBox = false;
        }

        

        

        private void 会员注册ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            addMan f = new addMan();
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.WindowState = FormWindowState.Maximized;
            panel2.Controls.Add(f);
            f.Show();
        }

        private void 会员查询ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            search f = new search();
            f.TopLevel = false;
            f.FormBorderStyle = FormBorderStyle.None;
            f.WindowState = FormWindowState.Maximized;
            panel2.Controls.Add(f);
            f.Show();
        }
    }
}
