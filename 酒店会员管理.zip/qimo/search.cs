﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace qimo
{
    public partial class search : Form
    {
        string sql;
        String connetStr = "server=127.0.0.1;port=3306;user=root;password=123456; database=hotel;";
        public search()
        {
            InitializeComponent();

        }


        private void Search_Load(object sender, EventArgs e)
        {

        }

        private void WebBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void SkinDateTimePicker1_SelectedValueChange(object sender, string Item)
        {

        }

        private void SkinButton4_Click(object sender, EventArgs e)
        {
            int index = skinDataGridView1.CurrentRow.Index;    //取得选中行的索引
            string idtext = skinDataGridView1.Rows[index].Cells[2].Value.ToString();
            string name = skinDataGridView1.Rows[index].Cells[1].Value.ToString();
            string upgrade = updata.Text.Trim();

            //txt_ProductId.Text为最终获取的选中行的ID值
            sql = string.Format("update `hotelmember` set `grade` = `grade`+ '{1}' WHERE `usrid` = '{0}'", idtext,upgrade);
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            MySqlCommand updataCmd = new MySqlCommand(sql, conn);
            int upResult = updataCmd.ExecuteNonQuery();
            if (upResult != 0)
            {
                MessageBox.Show(string.Format("{0}已加{1}分",name,upgrade), "温馨提示");
            }
            else
            {
                MessageBox.Show(string.Format("{0}加分失败",name), "温馨提示");
            }
            conn.Close();
        }


        private void SkinButton2_Click(object sender, EventArgs e)
        {
            int index = skinDataGridView1.CurrentRow.Index;    //取得选中行的索引
            string idtext = skinDataGridView1.Rows[index].Cells[2].Value.ToString();
            string name = skinDataGridView1.Rows[index].Cells[1].Value.ToString();
            string upgrade = updata.Text.Trim();

            //txt_ProductId.Text为最终获取的选中行的ID值
            sql = string.Format("update `hotelmember` set `grade` = `grade`- '{1}' WHERE `usrid` = '{0}'", idtext, upgrade);
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            MySqlCommand updataCmd = new MySqlCommand(sql, conn);
            int upResult = updataCmd.ExecuteNonQuery();
            if (upResult != 0)
            {
                MessageBox.Show(string.Format("{0}已使用{1}分", name, upgrade), "温馨提示");
            }
            else
            {
                MessageBox.Show(string.Format("{0}使用失败", name), "温馨提示");
            }
            conn.Close();
        }

        private void SkinButton1_Click(object sender, EventArgs e)
        {
            string timer = dateTimePicker1.Value.ToShortDateString();
            sql = string.Format("SELECT id,hotelmember.usrname,hotelmember.usrid," +
                "hotelmember.phoneNumber,hotelmember.location,sex,hotelmember.grade,hotelmember.dateTime " +
                "FROM hotelmember WHERE hotelmember.dateTime = '{0}'", timer);
            mysearch(sql);
        }

        private void SkinButton3_Click(object sender, EventArgs e)
        {
            
            
            string inputText = ZHsearch.Text.Trim();
            if (inputText.Length <= 7)
            {
                sql = string.Format("SELECT id,hotelmember.usrname,hotelmember.usrid," +
                "hotelmember.phoneNumber,hotelmember.location,sex,hotelmember.grade,hotelmember.dateTime " +
                "FROM hotelmember WHERE hotelmember.usrname = '{0}'", inputText);
                mysearch(sql);
            }
            else if (inputText.Length == 11)
            {
                sql = string.Format("SELECT id,hotelmember.usrname,hotelmember.usrid," +
                "hotelmember.phoneNumber,hotelmember.location,sex,hotelmember.grade,hotelmember.dateTime " +
                "FROM hotelmember WHERE hotelmember.phoneNumber = '{0}'", inputText);
                mysearch(sql);

            }
            else if (inputText.Length == 15)
            {
                sql = string.Format("SELECT id,hotelmember.usrname,hotelmember.usrid," +
                "hotelmember.phoneNumber,hotelmember.location,sex,hotelmember.grade,hotelmember.dateTime " +
                "FROM hotelmember WHERE hotelmember.usrid = '{0}'", inputText);
                mysearch(sql);

            }
            else if (inputText.Length == 18)
            {
                sql = string.Format("SELECT id,hotelmember.usrname,hotelmember.usrid," +
                "hotelmember.phoneNumber,hotelmember.location,sex,hotelmember.grade,hotelmember.dateTime " +
                "FROM hotelmember WHERE hotelmember.usrid = '{0}'", inputText);
                mysearch(sql);

            }
            else {
                MessageBox.Show("您的输入有误,请检查输入是否正确.","温馨提示");
            }
            ZHsearch.Clear();
            


        }
        public void mysearch(string sql) {
            
            
            MySqlConnection myconn = null;
            MySqlCommand mycom = null;
            myconn = new MySqlConnection(connetStr);
            myconn.Open();
            mycom = myconn.CreateCommand();
            
            mycom.CommandText = sql;
            MySqlDataAdapter adap = new MySqlDataAdapter(mycom);
            DataSet ds = new DataSet();
            adap.Fill(ds);
            skinDataGridView1.DataSource = ds.Tables[0].DefaultView;
            skinDataGridView1.Columns[1].HeaderText = "姓名";
            skinDataGridView1.Columns[2].HeaderText = "身份证号码";
            skinDataGridView1.Columns[3].HeaderText = "电话号码";
            skinDataGridView1.Columns[4].HeaderText = "户籍信息";
            skinDataGridView1.Columns[5].HeaderText = "性别";
            skinDataGridView1.Columns[6].HeaderText = "积分";
            skinDataGridView1.Columns[7].HeaderText = "首次入住";

            skinDataGridView1.Columns[0].Width = 50;
            skinDataGridView1.Columns[1].Width = 100;
            skinDataGridView1.Columns[2].Width = 130;
            skinDataGridView1.Columns[3].Width = 100;
            skinDataGridView1.Columns[4].Width = 140;
            skinDataGridView1.Columns[5].Width = 60;
            skinDataGridView1.Columns[6].Width = 60;
            myconn.Close();
            
        }

        private void Usrname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b' && !Char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Updata_TextChanged(object sender, EventArgs e)
        {

        }

        private void SkinTextBox1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SkinDateTimePicker1_SelectedValueChange_1(object sender, string Item)
        {
            
        }

        private void DateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
