﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;

namespace qimo
{
    public partial class addMan : Form
    {

        public addMan()
        {
            InitializeComponent();

        }


        private void SkinButton1_Click(object sender, EventArgs e)
        {
            String connetStr = "server=127.0.0.1;port=3306;user=root;password=123456; database=hotel;";
            // server=127.0.0.1/localhost 代表本机，端口号port默认是3306可以不写
            MySqlConnection conn = new MySqlConnection(connetStr);
            string id = usrid.Text.Trim();
            string name = usrname.Text.Trim();
            string phone = phonenumber.Text.Trim();

            try
            {
                conn.Open();

                if ((id.Length == 18 || id.Length == 15) && phone.Length == 11 && name != "")
                {
                    string msg = "确定需要添加 " + name + " 吗？";
                    if ((int)MessageBox.Show(msg, "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == 1)
                    {

                        MySqlCommand checkcmd = new MySqlCommand(string.Format("select Count(*) from hotelmember where usrid= '{0}'", id), conn);
                        object check = checkcmd.ExecuteScalar();
                        int count = Convert.ToInt32(check.ToString());


                        if (count == 0)
                        {
                            string localname;
                            try
                            {
                                string sql0 = "SELECT localtion FROM ip WHERE number = @ip";
                                MySqlParameter parameter0 = new MySqlParameter("@ip", id.Substring(0, 6));
                                MySqlCommand queryip = new MySqlCommand(sql0, conn);
                                queryip.Parameters.Add(parameter0);
                                localname = queryip.ExecuteScalar().ToString();
                            }
                            catch
                            {
                                localname = "未知";
                            }


                            string sql = "INSERT INTO hotelmember (usrid,usrname,phoneNumber,sex,location,grade,dateTime,dateBirthday)" +
                            "VALUES(@usrid, @usrname, @phonenumber, @sex, @local, 10 ,@dateTime,@dateOfBirth)";
                            MySqlParameter parameter1 = new MySqlParameter("@usrid", id);
                            MySqlParameter parameter2 = new MySqlParameter("@usrname", name);
                            MySqlParameter parameter3 = new MySqlParameter("@phonenumber", phone);
                            MySqlParameter parameter4 = new MySqlParameter("@sex", GetGenderByIdCard(id));
                            MySqlParameter parameter5 = new MySqlParameter("@dateOfBirth", GetBirthday(id));
                            MySqlParameter parameter6 = new MySqlParameter("@dateTime", GetTimeStamp());
                            MySqlParameter parameter7 = new MySqlParameter("@local", localname);

                            MySqlCommand cmd = new MySqlCommand(sql, conn);
                            cmd.Parameters.Add(parameter1);
                            cmd.Parameters.Add(parameter2);
                            cmd.Parameters.Add(parameter3);
                            cmd.Parameters.Add(parameter4);
                            cmd.Parameters.Add(parameter5);
                            cmd.Parameters.Add(parameter6);
                            cmd.Parameters.Add(parameter7);
                            //MessageBox.Show(rmname+"添加成功", "登录提示");
                            int result = cmd.ExecuteNonQuery();
                            if (result == 1)
                            {
                                MessageBox.Show(name + "添加成功", "温馨提示");
                            }
                            else
                            {
                                MessageBox.Show(name + "添加失败", "温馨提示");
                            }
                        }
                        else
                        {
                            string updatesql = string.Format("update `hotelmember` set `grade` = `grade`+ 10 WHERE `usrid` = '{0}'", id);
                            MySqlCommand updataCmd = new MySqlCommand(updatesql, conn);
                            int upResult = updataCmd.ExecuteNonQuery();
                            if (upResult != 0)
                            {
                                MessageBox.Show(name + "是一位老顾客,积分已加10", "温馨提示");
                            }
                            else
                            {
                                MessageBox.Show(name + "加分失败", "温馨提示");
                            }
                        }

                    }
                }
                else
                {
                    MessageBox.Show("请检查身份证或手机号是否填写正确", "温馨提示");
                }


            }
            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("无法连接到服务器,请联系胡啸林!", "错误提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                        break;
                    case 1045:
                        MessageBox.Show("用户名或密码错误,请再试一次!", "错误提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                        break;
                    default:
                        MessageBox.Show(ex.Message, "错误提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
                        break;
                }
            }
            finally
            {
                conn.Close();
            }
            usrid.Clear();
            usrname.Clear();
            phonenumber.Clear();
        }

        private void SkinButton2_Click(object sender, EventArgs e)
        {
            usrid.Clear();
            usrname.Clear();
            phonenumber.Clear();
        }


        public static string GetGenderByIdCard(string idCard)
        {
            string sex;
            if (idCard.Length == 18) {
                if (Convert.ToBoolean(int.Parse(idCard.Substring(16, 1)) % 2))
                {
                    sex = "男";
                }
                else
                {
                    sex = "女";
                }
                return sex;
            }
            if (idCard.Length == 15)
            {
                if (Convert.ToBoolean(int.Parse(idCard.Substring(14, 1)) % 2))
                {
                    sex = "男";
                }
                else
                {
                    sex = "女";
                }
                return sex;
            }
            return "男";


        }

        public static string GetBirthday(string idCard)
        {
            System.Text.RegularExpressions.Regex regex = null;
            if (idCard.Length == 18)
            {
                regex = new Regex(@"^\d{17}(\d|x|X)$");
                if (regex.IsMatch(idCard))
                {
                    string year = idCard.Substring(6, 4);
                    string month = idCard.Substring(10, 2);
                    string date = idCard.Substring(12, 2);
                    string result = year + "-" + month + "-" + date;
                    return result;

                }
                else
                {
                    MessageBox.Show("身份证格式错误");
                }

            }
            else if (idCard.Length == 15)
            {
                regex = new Regex(@"^\d{15}");
                if (regex.IsMatch(idCard))
                {
                    string year = idCard.Substring(6, 2);
                    string month = idCard.Substring(8, 2);
                    string date = idCard.Substring(10, 2);
                    string result = year + "-" + month + "-" + date;
                    return result;
                }
                else
                {
                    MessageBox.Show("身份证格式错误");
                }

            }
            return "0000-00-00";
            


        }
        public string GetTimeStamp()
        {
            
            return DateTime.Now.ToShortDateString().ToString();
        }

        private void addman_Load(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }


        private void Usrid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b' && !Char.IsDigit(e.KeyChar) && e.KeyChar != 'x')
            {
                e.Handled = true;
            }
            
        }

        private void Phonenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b' && !Char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Phonenumber_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
